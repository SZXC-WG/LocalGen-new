# Donate Please!

[![QIM4p.md.jpg](https://i.imgtg.com/2023/01/19/QIM4p.md.jpg)](https://imgtg.com/image/QIM4p)
[![Quwij.md.jpg](https://i.imgtg.com/2023/01/19/Quwij.md.jpg)](https://imgtg.com/image/Quwij)
